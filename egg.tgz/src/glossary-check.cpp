// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Check glossary usage\n", stdout);
  return lionss_run_workload("glossary-check");
}
