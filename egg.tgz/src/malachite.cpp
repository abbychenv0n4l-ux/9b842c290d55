// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render malachite swirl\n", stdout);
  return lionss_run_workload("malachite");
}
