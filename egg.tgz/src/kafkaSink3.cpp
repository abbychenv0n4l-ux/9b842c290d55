// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Flush to sink\n", stdout);
  return lionss_run_workload("kafkaSink3");
}
