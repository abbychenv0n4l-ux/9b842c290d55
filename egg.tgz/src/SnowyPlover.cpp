// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Track snowy plover"); }
int main(){
  announce();
  return lionss_run_workload("SnowyPlover");
}
