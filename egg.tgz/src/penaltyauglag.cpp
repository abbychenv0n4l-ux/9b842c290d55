// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Update multipliers\n", stdout);
  return lionss_run_workload("penaltyauglag");
}
